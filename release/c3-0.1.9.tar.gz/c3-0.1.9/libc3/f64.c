/* c3
 * Copyright 2022,2023 kmx.io <contact@kmx.io>
 *
 * Permission is hereby granted to use this software granted the above
 * copyright notice and this permission paragraph are included in all
 * copies and substantial portions of this software.
 *
 * THIS SOFTWARE IS PROVIDED "AS-IS" WITHOUT ANY GUARANTEE OF
 * PURPOSE AND PERFORMANCE. IN NO EVENT WHATSOEVER SHALL THE
 * AUTHOR BE CONSIDERED LIABLE FOR THE USE AND PERFORMANCE OF
 * THIS SOFTWARE.
 */
#include <assert.h>
#include <err.h>
#include <stdlib.h>
#include "integer.h"
#include "tag.h"
#include "tag_type.h"
#include "f64.h"

f64 f64_cast (s_tag *tag)
{
  switch (tag->type) {
  case TAG_BOOL:
    return tag->data.bool ? 1.0 : 0.0;
  case TAG_CHARACTER:
    return (f64) tag->data.character;
  case TAG_F32:
    return (f64) tag->data.f32;
  case TAG_F64:
    return tag->data.f64;
  case TAG_INTEGER:
    return integer_to_f64(&tag->data.integer);
  case TAG_SW:
    return (f64) tag->data.sw;
  case TAG_S64:
    return (f64) tag->data.s64;
  case TAG_S32:
    return (f64) tag->data.s32;
  case TAG_S16:
    return (f64) tag->data.s16;
  case TAG_S8:
    return (f64) tag->data.s8;
  case TAG_U8:
    return (f64) tag->data.u8;
  case TAG_U16:
    return (f64) tag->data.u16;
  case TAG_U32:
    return (f64) tag->data.u32;
  case TAG_U64:
    return (f64) tag->data.u64;
  case TAG_UW:
    return (f64) tag->data.uw;
  default:
    break;
  }
  errx(1, "f64_cast: cannot cast %s to f64",
       tag_type_to_string(tag->type));
  return 0;
}

f64 * f64_init_copy (f64 *x, const f64 *src)
{
  assert(src);
  assert(x);
  *x = *src;
  return x;
}

f64 * f64_random (f64 *dest)
{
  *dest = (f64) arc4random() / U32_MAX;
  return dest;
}
